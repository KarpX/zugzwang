#!/bin/sh
printf '\033c\033]0;%s\a' Zugzwang
base_path="$(dirname "$(realpath "$0")")"
"$base_path/build-linux.x86_64" "$@"
